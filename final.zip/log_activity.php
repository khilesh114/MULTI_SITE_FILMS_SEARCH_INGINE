<?php
// log_activity.php

// Get the current date and time
$visit_time = date("Y-m-d H:i:s");

// Get user agent (browser details)
$user_agent = $_SERVER['HTTP_USER_AGENT'];

// Get IP address
$ip_address = $_SERVER['REMOTE_ADDR'];

// Time spent (optional, for later use if required in AJAX)
$time_spent = isset($_POST['timeSpent']) ? $_POST['timeSpent'] : '0';

// Prepare log data
$log_data = "Visit Time: $visit_time | User Agent: $user_agent | IP Address: $ip_address | Time Spent: $time_spent sec\n";

// Log the data into a file
file_put_contents('user_log.txt', $log_data, FILE_APPEND);

// Optionally, you can return a success message (though we won't print it)
echo "Log recorded successfully!";
