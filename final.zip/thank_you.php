<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You for Your Donation!</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 0;
            background-color: #f0f8ff;
        }
        .container {
            margin-top: 100px;
        }
        h1 {
            color: #333;
        }
        p {
            color: #555;
        }
        .donation {
            font-size: 1.2em;
            font-weight: bold;
            color: #28a745;
        }
        a {
            text-decoration: none;
            color: #007bff;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Thank You for Your Donation!</h1>
        <p>Your generous donation is highly appreciated.</p>
        <p class="donation">Donation Amount: ₹<?php echo htmlspecialchars($_GET['amount']); ?> INR</p>
        <p>We hope to see you again!</p>
        <p><a href="index.php">Back to Home</a></p>
    </div>
</body>
</html>
