<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the donation amount from the form
    $donationAmount = $_POST['amount'];
    
    // Get the user agent and time spent from the form
    $timeSpent = $_POST['timeSpent'];
    $userAgent = $_POST['userAgent'];

    // Get the current date and time
    $currentDateTime = date('Y-m-d H:i:s');

    // Define the allowed file types
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];

    // Check if the file is uploaded and valid
    if (isset($_FILES['screenshot']) && $_FILES['screenshot']['error'] == 0) {
        $fileTmpPath = $_FILES['screenshot']['tmp_name'];
        $fileName = basename($_FILES['screenshot']['name']);
        $fileSize = $_FILES['screenshot']['size'];
        $fileType = mime_content_type($fileTmpPath);

        // Validate the file type
        if (in_array($fileType, $allowedTypes)) {
            // Limit the file size (5MB max)
            if ($fileSize <= 5 * 1024 * 1024) {
                $uploadFolder = 'uploads/';
                $destination = $uploadFolder . $fileName;

                // Move the file to the uploads folder
                if (move_uploaded_file($fileTmpPath, $destination)) {
                    // Prepare the log entry
                    $logEntry = "User donated: ₹" . $donationAmount . " INR | Date/Time: " . $currentDateTime . " | Time Spent: " . $timeSpent . " seconds | User Agent: " . $userAgent . " | Screenshot: " . $fileName . "\n";

                    // Append the log entry to user_log.txt
                    file_put_contents('user_log.txt', $logEntry, FILE_APPEND);

                    // Show a thank you message
                    echo "<h2>Thank you for your donation of ₹" . $donationAmount . " INR!</h2>";
                } else {
                    echo "<h2>Failed to upload screenshot. Please try again.</h2>";
                }
            } else {
                echo "<h2>File size exceeds the 5MB limit.</h2>";
            }
        } else {
            echo "<h2>Invalid file type. Only JPEG, PNG, and GIF files are allowed.</h2>";
        }
    } else {
        echo "<h2>Please upload a valid screenshot.</h2>";
    }
} else {
    echo "<h2>Invalid request method.</h2>";
}
?>
